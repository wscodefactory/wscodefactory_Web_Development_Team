# 👋 Welcome 👋
-  This is @wscodefactory
- ⚓🚢 I'm currently serving in the military.
- 🌱 I had learned Python,Java,C.
- 💻 I'm currently studying web development.

<!---
wscodefactory/wscodefactory is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
